﻿using VisitorPattern.Implementations;

namespace VisitorPattern.Interfaces
{
	public interface IDocumentConverter
	{
		void Convert(Paragraph paragraph);

		void Convert(Header header);
	}
}

﻿using System;
using VisitorPattern.Implementations;

namespace VisitorPattern
{
	class Program
	{
		public static void Main(string[] args)
		{
			Document document = new Document();
			document.Add(new Paragraph());
			document.Add(new Header());

			Console.WriteLine("Invoking Html Converter");
			document.Convert(new HtmlConverter());
		}
	}
}

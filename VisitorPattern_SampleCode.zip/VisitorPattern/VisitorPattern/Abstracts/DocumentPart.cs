﻿using VisitorPattern.Interfaces;

namespace VisitorPattern.Abstracts
{
	public abstract class DocumentPart
	{
		public abstract void Paint();

		public abstract void Save();

		public abstract void Convert(IDocumentConverter converter);
	}
}

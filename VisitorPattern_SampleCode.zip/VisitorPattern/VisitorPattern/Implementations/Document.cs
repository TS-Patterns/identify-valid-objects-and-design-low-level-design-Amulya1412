﻿using System.Collections.Generic;
using VisitorPattern.Abstracts;
using VisitorPattern.Interfaces;

namespace VisitorPattern.Implementations
{
	public class Document: DocumentPart
	{
		public static List<DocumentPart> parts = new List<DocumentPart>();

		public void Add(DocumentPart part)
		{
			parts.Add(part);
		}

		public override void Paint()
		{
			foreach (DocumentPart part in parts)
			{
				part.Paint();
			}
		}

		public override void Save()
		{
			foreach (DocumentPart part in parts)
			{
				part.Save();
			}
		}

		public override void Convert(IDocumentConverter converter)
		{
			foreach (DocumentPart part in parts)
			{
				part.Convert(converter);
			}
		}
	}
}

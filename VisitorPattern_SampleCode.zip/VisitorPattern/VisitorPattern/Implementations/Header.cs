﻿using System;
using VisitorPattern.Abstracts;
using VisitorPattern.Interfaces;

namespace VisitorPattern.Implementations
{
	public class Header : DocumentPart
	{
		public override void Convert(IDocumentConverter converter)
		{
			converter.Convert(this);
		}

		public override void Paint()
		{
			Console.WriteLine("Painting Header");
		}

		public override void Save()
		{
			Console.WriteLine("Saving Header");
		}
	}
}

﻿using System;
using System.Threading;
using VisitorPattern.Interfaces;

namespace VisitorPattern.Implementations
{
	public class HtmlConverter: IDocumentConverter
	{
		public void Convert(Header header)
		{
			Console.WriteLine("Converting Header");
			Thread.Sleep(5000);
		}

		public void Convert(Paragraph paragraph)
		{
			Console.WriteLine("Converting Paragraph");
			Thread.Sleep(5000);			
		}
	}
}

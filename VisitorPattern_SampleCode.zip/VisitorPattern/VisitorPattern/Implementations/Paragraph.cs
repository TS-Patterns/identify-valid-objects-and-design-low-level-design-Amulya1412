﻿using System;
using VisitorPattern.Abstracts;
using VisitorPattern.Interfaces;

namespace VisitorPattern.Implementations
{
	public class Paragraph: DocumentPart
	{
		public override void Convert(IDocumentConverter converter)
		{
			converter.Convert(this);
		}

		public override void Paint()
		{
			Console.WriteLine("Painting Paragraph");
		}

		public override void Save()
		{
			Console.WriteLine("Saving Paragraph");
		}
	}
}
